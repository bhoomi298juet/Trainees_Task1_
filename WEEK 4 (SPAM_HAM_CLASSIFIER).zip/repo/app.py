import numpy as np
import pandas as pd
import joblib
import streamlit as st
tfidf = joblib.load(open('vectorizerr.pkl', 'rb'))
model = joblib.load(open('spam_emails_classfyy.pkl', 'rb'))
st.title('MAIL CLASSFIER')
input_sms = st.text_input('Enter the message')
if st.button('predict'):
    # preprocessing
    # vectorize
    vector_input = tfidf.transform([input_sms])
    # predict
    result = model.predict(vector_input)
    # display
    if result == 1:
        st.header("spam")
    else:
        st.header("ham")

#streamlit run app.py
# Congratulations! You've Won a $500 Gift Card!
#Weekly Team Update – Project Athena


