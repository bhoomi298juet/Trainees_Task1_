import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import GaussianNB
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import string

# Download once
nltk.download('punkt')
nltk.download('stopwords')

ps = PorterStemmer()

#  Text preprocessing function
def transform_text(text):
    text = text.lower()
    words = nltk.word_tokenize(text)
    y = []
    for word in words:
        if word.isalnum() and word not in stopwords.words('english') and word not in string.punctuation:
            y.append(ps.stem(word))
    return " ".join(y)

#  More realistic dataset
X = [
    "Free entry in 2 a wkly comp to win FA Cup final tkts",
    "U dun say so early hor... U c already then say...",
    "Nah I don't think he goes to usf, he lives around here",
    "Free tickets now!!! Win money instantly",
    "Hey, are we still meeting for dinner?",
    "Get your prize now, claim fast!",
    "Reminder: your appointment is at 4 PM",
    "You have won ₹100000! Click to claim",
    "Let’s meet tomorrow to discuss the project",
    "Click here to get 90% off on your order"
]
y = [1, 0, 0, 1, 0, 1, 0, 1, 0, 1]  # spam = 1, not spam = 0

# 🧹 Preprocess messages
X_transformed = [transform_text(msg) for msg in X]

#  TF-IDF Vectorization
vectorizer = TfidfVectorizer()
X_vectorized = vectorizer.fit_transform(X_transformed).toarray()  # GaussianNB needs dense

#  Train the model
model = GaussianNB()
model.fit(X_vectorized, y)

#  Save the model and vectorizer
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

print("✅ Model and vectorizer saved successfully.")
