import 'package:flutter/material.dart';
import 'db_helper.dart';



class NoteApp extends StatelessWidget {
  const NoteApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SQLite Notes',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const NoteHomePage(),
    );
  }
}

class NoteHomePage extends StatefulWidget {
  const NoteHomePage({super.key});
  @override
  State<NoteHomePage> createState() => _NoteHomePageState();
}

class _NoteHomePageState extends State<NoteHomePage> {
  final db = DBHelper();
  List<Note> notes = [];

  @override
  void initState() {
    super.initState();
    _refreshNotes();
  }

  Future<void> _refreshNotes() async {
    notes = await db.getNotes();
    setState(() {});
  }

  void _openNoteScreen({Note? note}) {
    final isNew = note == null;
    final titleCtrl = TextEditingController(text: note?.title);
    final contentCtrl = TextEditingController(text: note?.content);

    showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(isNew ? 'New Note' : 'Edit Note'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Title')),
            TextField(controller: contentCtrl, decoration: const InputDecoration(labelText: 'Content')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
                onPressed: () async {
                  final t = titleCtrl.text.trim();
                  final c = contentCtrl.text.trim();
                  if (t.isEmpty && c.isEmpty) return;

                  if (isNew) {
                    await db.insertNote(Note(title: t, content: c));
                  } else {
                    note!.title = t; note.content = c;
                    await db.updateNote(note);
                  }
                  Navigator.pop(context);
                  _refreshNotes();
                },
                child: Text(isNew ? 'Add' : 'Save')
            ),
          ],
        )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SQLite Notes')),
      body: notes.isEmpty
          ? const Center(child: Text('No notes yet.'))
          : ListView.builder(
          itemCount: notes.length,
          itemBuilder: (c, i) {
            final note = notes[i];
            return Card(
              child: ListTile(
                title: Text(note.title),
                subtitle: Text(
                  note.content,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => _openNoteScreen(note: note),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.redAccent),
                  onPressed: () async {
                    await db.deleteNote(note.id!);
                    _refreshNotes();
                  },
                ),
              ),
            );
          }
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openNoteScreen(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
