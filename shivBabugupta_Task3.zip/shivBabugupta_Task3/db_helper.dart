import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'models/note.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._();
  factory DBHelper() => _instance;
  DBHelper._();

  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final path = join(await getDatabasesPath(), 'notes.db');
    return openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''
        CREATE TABLE notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT,
          content TEXT
        )
      ''');
    });
  }

  Future<int> insertNote(Note note) async {
    final dbClient = await db;
    return dbClient.insert('notes', note.toMap());
  }

  Future<List<Note>> getNotes() async {
    final dbClient = await db;
    final maps = await dbClient.query('notes', orderBy: 'id DESC');
    return maps.map((m) => Note.fromMap(m)).toList();
  }

  Future<int> updateNote(Note note) async {
    final dbClient = await db;
    return dbClient.update('notes', note.toMap(), where: 'id = ?', whereArgs: [note.id]);
  }

  Future<int> deleteNote(int id) async {
    final dbClient = await db;
    return dbClient.delete('notes', where: 'id = ?', whereArgs: [id]);
  }
}
