
import 'package:flutter/material.dart';

class FrontPage extends StatefulWidget {
  const FrontPage({super.key});

  @override
  State<FrontPage> createState() => _FrontPageState();
}

class _FrontPageState extends State<FrontPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Two Image Buttons',
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: const TwoImageButtonsPage(),
    );
  }
}


class TwoImageButtonsPage extends StatelessWidget {
  const TwoImageButtonsPage({super.key});

  void _onImageTap(BuildContext context, String id) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Tapped: $id')),
    );
    // Add real navigation or action logic here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page'),
        centerTitle: true,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth > 600;

          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: isWide
                  ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildImageButton(context, 'Button 1', 'assets/img1.png'),
                  const SizedBox(width: 40),
                  _buildImageButton(context, 'Button 2', 'assets/img2.png'),
                ],
              )
                  : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildImageButton(context, 'Button 1', 'assets/img1.png'),
                  const SizedBox(height: 24),
                  _buildImageButton(context, 'Button 2', 'assets/img2.png'),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildImageButton(BuildContext context, String id, String assetPath) {
    return GestureDetector(
      onTap: () => _onImageTap(context, id),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: 160,
          height: 160,
          decoration: BoxDecoration(
            color: Colors.grey[800],
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 4)),
            ],
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  assetPath,
                  fit: BoxFit.cover,
                  errorBuilder: (c, e, s) => Center(child: Icon(Icons.broken_image, size: 48, color: Colors.white24)),
                ),
              ),
              Positioned.fill(
                child: Container(color: Colors.black26),
              ),
              Center(
                child: Text(
                  id,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

